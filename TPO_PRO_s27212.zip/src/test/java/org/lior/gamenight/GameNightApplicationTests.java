package org.lior.gamenight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameNightApplicationTests {

	@Test
	void contextLoads() {
	}

}
