package org.lior.gamenight.Entities;

public enum Language {
    English, Polish, Ukrainian
}
