package org.lior.gamenight.Entities;

public enum GameCategory {
    Strategy, Family, Cooperative, Party, Card , Abstract
}
